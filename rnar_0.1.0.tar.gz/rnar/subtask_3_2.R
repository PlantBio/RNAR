#This function is for subtask_3_2 to pull data for gene symbols from an online database for item under GeneID column. 
#Then the data is used to draw a volcano plot to represent highly regulated items between condition 1 and condition 2.

#install.packages("ggrepel")
#load library
library(ggrepel)
library(biomaRt)
library(biomartr)
library(readr)


listMarts(host="plants.ensembl.org")
m <- useMart(biomart="plants_mart",host="plants.ensembl.org", dataset = "athaliana_eg_gene")
results = read_csv("minus_plus.csv") #this is a toy data use the real data to read while merging the subtasks
results = mutate(results, significance=ifelse(results$p.adjust<0.05, "FDR<0.05", "Not Sig."))
results$GeneID <- gsub("\\.[0-9]*$", "", results$GeneID) #this code piece deletes the part after the . symbol in GeneID column

BM <- biomart(genes      = results$GeneID,
        mart       = "plants_mart",
        dataset    = "athaliana_eg_gene",
        attributes = c("start_position","end_position","external_gene_name"),
        filters    = "ensembl_gene_id")

listAttributes(m) #run to see options for attributes to select

joined <- left_join(results, BM, by = c("GeneID" = "ensembl_gene_id"))

p = ggplot(joined, aes(logFC, -log10(pvalue))) + 
geom_point(aes(col=significance)) +
  scale_color_manual(values=c("red", "black"))

p_title <- p+geom_text_repel(data=dplyr::filter(joined, p.adjust<0.01, (logFC<(-1) | logFC>(1))), 
                             aes(label=external_gene_name), size = 3)+ 
  ggtitle("Condition 1 vs Condition 2") + 
  theme(plot.title = element_text(hjust = 0.5))
print(p_title)
