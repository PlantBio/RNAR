library(tidyverse)
library(dplyr)
# Load BiocManager and GenomicFeatures libraries to extract genomic positions of genes
# if (!requireNamespace("BiocManager", quietly = TRUE))
# install.packages("BiocManager")
# BiocManager::install("TxDb.Athaliana.BioMart.plantsmart28", version = "3.8")
library(BiocManager)
# install.packages("GenomicFeatures")
library(GenomicFeatures)
library(TxDb.Athaliana.BioMart.plantsmart28)
# Load ggbio library to use plotGrandLinear function
# install.packages("ggbio")
library(ggbio)
# Import data
toy_data <- read.csv("toy_data.csv")
# Filter for FDR
topgenes <- toy_data %>%
    filter((FDR) <= 0.01) %>%
    mutate(rank = rank(FDR, ties.method = "first"))
# Export transcripts from database
txdb <- TxDb.Athaliana.BioMart.plantsmart28
tr <- transcriptsBy(txdb, by = "gene")
# Export exon ranges from database
exoRanges <- exonsBy(txdb, "gene") %>%
  range() %>%
  unlist()

## This is to remove the ".x" at the end of each gene name so the names agree with the ones in the databases. These characters at the end of each name represent alternative transcripts of the same gene so they can be ommited for this case.  
FC_data$ID <- gsub("\\.[0-9]*$", "", FC_data$ID)
FC_data2 = FC_data[!duplicated(FC_data$ID),]
FC_data3 <- FC_data2 %>% 
  mutate(fold = -log10(FC_data2$logFC)) %>% 
  drop_na()
# Couldn't find a way to remove infinite values

# Match exon regions with genes identified from data
# toy_data or filtered data
sigRegions <- exoRanges[na.omit(match(FC_data3$ID, names(exoRanges)))]
mcols(sigRegions) <- FC_data3[match(names(sigRegions), FC_data3$ID), ]
sigRegions
sigRegions <- keepSeqlevels(sigRegions,
  value = c(1:5),
  pruning.mode = "tidy"
)

# Now plot
plotGrandLinear(sigRegions, aes(y = fold), cutoff.size = 1) + scale_color_brewer(palette = "Dark2") +
  xlab("Chromosome") +
  ggtitle("Significantly enriched genome positions")
