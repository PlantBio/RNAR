heatmapfc <-function (data) {
  #rearrange the data and group by different types of fold change in case we have fold change data among more conditions (e.g. C1 vs C3, C2 vs C3, etc.)
  heatmapdat <- data %>% 
    dplyr::select(ID, contains("Fold")) %>% 
    gather (key= "Foldvar", value= "Fold_change", -ID) %>% 
    group_by(Foldvar)
  
  #values with min and max values in 'fold' column, to be used in the legend
  lim <- c(ceiling(min(heatmapdat$Fold_change)),  ceiling(max(heatmapdat$Fold_change)))
  #top10 and bottom 10 items
  maxfold <- top_n(heatmapdat, 10)
  minfold <- top_n(heatmapdat, -10)
  max_min <- base::rbind(maxfold, minfold)
  #plot
  max_min %>% 
    ggplot (aes("C1 vs C2", y= ID)) + #"C1 vs C2" should be change to x=Foldvar when data have more fold change from different conditions
    geom_tile(aes(fill = Fold_change)) + 
    scale_fill_gradient(low="red", high="blue", limits= lim) +
    labs(x="Fold Change",
         y ="Gene ID",
         title="Top 10 and bottom 10 genes changed", adj = 0.5) +
    coord_fixed(ratio =0.1)+
    theme(panel.background = element_blank(),
           plot.background = element_blank())+
    theme(plot.title = element_text(hjust = 0.5)) +
    scale_y_discrete(position = "right")  
    
}
