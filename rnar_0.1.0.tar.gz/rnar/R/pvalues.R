#function for p-values, if there is no difference between conditions (same mean values) p-values is 1.
pvalues <- function(x) {
  p <- numeric(nrow(x))
  for (i in c(1: nrow(x))) {
    c1 <- as.numeric(select(x, contains("C1"))[i, ])
    c2 <- as.numeric(select(x, contains("C2"))[i, ])
    if (mean(c1) == mean(c2)) {
      p[i] = 1
    }
    else if (sd(c1) == 0 & sd(c2) == 0) {
      p[i] = 0
    }
    else {
      p[i] = findpvalue(c1, c2)
    }
  }
  p
}
