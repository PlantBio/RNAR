#function processes data and prints values
processdat <- function(x) {
  print(mutate(x, p.values = pvalues(x), p.adjust = padjust(x)))
}
