#function calculates FDR based on BH correction
padjust <- function(x) {
  p.adjust(pvalues(x),"fdr")
}
