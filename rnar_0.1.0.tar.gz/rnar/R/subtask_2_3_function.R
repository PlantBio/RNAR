#this function uses the mean values of Condition 1 (C1) and Condition 2 (C2), and calculates the difference between their numerical values on a logarithmic scale.

FC_function <- function(data){
  mutate(data, Fold = log2(abs(C1))- log2(abs(C2)))
}
