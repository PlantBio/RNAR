volcanoplot <- function(results){

  listMarts(host="plants.ensembl.org")
  m <- useMart(biomart="plants_mart",host="plants.ensembl.org", dataset = "athaliana_eg_gene")
  resultsFDR <- mutate(FCdata, significance = ifelse(FCdata$p.adjust<0.05, "FDR<0.01", "Not Sig."))
  resultsFDR$ID <- gsub("\\.[0-9]*$", "", resultsFDR$ID) #this code piece deletes the part after the . symbol in the ID column
  
  BM <- biomart(genes      = resultsFDR$ID,
                mart       = "plants_mart",
                dataset    = "athaliana_eg_gene",
                attributes = c("start_position","end_position","external_gene_name"),
                filters    = "ensembl_gene_id")
  
  listAttributes(m) #run to see options for attributes to select
  resultsFDR <- distinct(resultsFDR)
  BM <- distinct(BM)
  
  joined <- inner_join(resultsFDR, BM, by = c("ID" = "ensembl_gene_id"))
  joinedF <- filter(joined, p.adjust<0.05, (Fold<(-4) | Fold>(4)))
  
  
  p = ggplot(joined, aes(Fold, -log10(p.values))) + 
    geom_point(aes(col=significance)) +
    scale_color_manual(values=c("red", "black"))
  
  p_title <- p + geom_text_repel(data = joinedF, aes(label = external_gene_name), size = 3) + 
    ggtitle("Condition 1 vs Condition 2") + 
    theme(plot.title = element_text(hjust = 0.5))
  print(p_title)
}
