library(tidyverse)
library(tidyr)
library(ggplot2)
library(broom)
library(stringr)
library(magrittr)
# library(devtools)
# install_github("vqv/ggbiplot")
library(ggbiplot)
library(dplyr)

# Just following the process for cleaning and calculations first
toy_data <- read.csv("toy_data.csv")
rawdat <- read.csv("raw-data-template-AdvR_Project.csv")

cleandat <- function(rawdat) {
  rawdat <- rawdat %>% drop_na()
  trialmean <- rawdat %>%
    gather(key = "cr", value = "value", -1) %>%
    mutate(crsub = substr(cr, 1, 5)) %>%
    group_by(ID, crsub) %>%
    summarize(mean = mean(value)) %>%
    spread(crsub, mean)
  repmean <- trialmean %>%
    gather(key = "cr", value = "value", -1) %>%
    mutate(csub = substr(cr, 1, 2)) %>%
    group_by(ID, csub) %>%
    summarize(mean = mean(value)) %>%
    spread(csub, mean)
  cleandat <- rawdat %>%
    left_join(trialmean, by = "ID") %>%
    left_join(repmean, by = "ID")
}

cleandata <- cleandat(rawdat)

cleandata <- cleandat(rawdat) %>%
  select("ID", "C1_R1", "C1_R2", "C1_R3", "C2_R1", "C2_R2", "C2_R3", "C1", "C2")

findpvalue <- function(x,y) {
  t.test(x,y,var.equal = FALSE)$p.value
}

pvalues <- function(x) {
  p <- numeric(nrow(x))
  for (i in c(1: nrow(x))) {
    c1 <- as.numeric(select(x, contains("C1"))[i, ])
    c2 <- as.numeric(select(x, contains("C2"))[i, ])
    if (mean(c1) == mean(c2)) {
      p[i] = 1
    }
    else if (sd(c1) == 0 & sd(c2) == 0) {
      p[i] = 0
    }
    else {
      p[i] = findpvalue(c1, c2)
    }
  }
  p
}

padjust <- function(x) {
  p.adjust(pvalues(x),"fdr")
}

processdat <- function(x) {
  print(mutate(cleandat(x),p.values = pvalues(x), p.adjust = padjust(x)))
}

final_values <- processdat(cleandata)

FC_function <- function(data){
  mutate(data, logFC = log2(abs(C1))- log2(abs(C2)))
}

FC_data <- FC_function(final_values)

sig_reg <- function(clean_data, fold) {
  if (nrow(clean_data %>% filter(logFC > fold & p.values < 0.05)) == 0) {
    print("No significantly upregulated genes were detected. Try a different fold value.")
  } else {
    sig_up <- clean_data %>% 
      filter(logFC > fold & p.values < 0.05) %>% 
      assign("sig_up",.,envir = .GlobalEnv) %>% 
      print()
  }
  
  if (nrow(clean_data %>% filter(logFC < -fold & p.values < 0.05)) == 0) {
    print("No significantly downregulated genes were detected. Try a different fold value.")
  } else {
    sig_down <- clean_data %>% 
      filter(logFC < -fold & p.values < 0.05) %>% 
      assign("sig_down",.,envir = .GlobalEnv) %>% 
      print()
  }
}

sig_reg(FC_data, 2)

sig_genes <- rbind(sig_down, sig_up)

# PCA STARTS HERE

# This is to remove the ".x" at the end of each gene name so the names agree with the ones in the databases. These characters at the end of each name represent alternative transcripts of the same gene so they can be ommited for this case.  
cleandata$ID <- gsub("\\.[0-9]*$", "", cleanedata$ID)

# grouping
cond_groups <- c(rep("C1"), rep("C2"))

pca <- prcomp(sig_genes[, c("C1", "C2")], center = TRUE, scale. = TRUE)
summary(pca)
pca$x
ggbiplot(pca)
ggbiplot(pca, groups = cond_groups)
