#this function performs the t.test for two groups of samples x and y. The output is the p-value.
findpvalue <- function(x,y) {
  t.test(x,y,var.equal = FALSE)$p.value
}

#this function find the p-values for each row of the data set.
pvalues <- function(x) {
  p <- numeric(nrow(x))
  for (i in c(1: nrow(x))) {
    c1 <- as.numeric(select(x, contains("C1"))[i, ])
    c2 <- as.numeric(select(x, contains("C2"))[i, ])
    if (mean(c1) == mean(c2)) {
      p[i] = 1
    }
    else if (sd(c1) == 0 & sd(c2) == 0) {
      p[i] = 0
    }
    else {
      p[i] = findpvalue(c1, c2)
    }
  }
  p
}

#this function find the p-adjust using "fdr" method
padjust <- function(x) {
  p.adjust(pvalues(x),"fdr")
}


#this function add the pvalues and p-adjust values to the data that has been cleaned, i.e. contains the mean values.
processdat <- function(x) {
  print(mutate(cleandat(x),p.values = pvalues(x), p.adjust = padjust(x)))
}