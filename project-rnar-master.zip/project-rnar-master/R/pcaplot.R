pcaplot <- function(x){
sig_reg(x, 2)

sig_genes <- rbind(sig_down, sig_up)

# PCA STARTS HERE

# grouping
cond_groups <- c(rep("C1"), rep("C2"))

pca <- prcomp(sig_genes[, c("C1", "C2")], center = TRUE, scale. = TRUE)
summary(pca)
pca$x
ggbiplot(pca)
ggbiplot(pca, groups = cond_groups)
}
