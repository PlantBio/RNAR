sig_reg <- function(data, value) {
    sig_up <- data %>% 
        filter(Fold > value & p.values < 0.05) %>% 
        assign("sig_up",.,envir = .GlobalEnv) %>% 
        print()
    sig_down <- data %>% 
        filter(Fold < -(value) & p.values < 0.05) %>% 
        assign("sig_down",.,envir = .GlobalEnv) %>% 
        print()
}
