manhattanplot <- function(FCdata){
# Filter for FDR
  topgenes <- FCdata %>%
    filter((FCdata$p.adjust) <= 0.01) %>%
    mutate(rank = rank(p.adjust, ties.method = "first"))
  # Export transcripts from database
  txdb <- TxDb.Athaliana.BioMart.plantsmart28
  tr <- transcriptsBy(txdb, by = "gene")
  # Export exon ranges from database
  exoRanges <- exonsBy(txdb, "gene") %>%
    range() %>%
    unlist()
  
  ## This is to remove the ".x" at the end of each gene name so the names agree with the ones in the databases. These characters at the end of each name represent alternative transcripts of the same gene so they can be ommited for this case.  
  FCdata$ID <- gsub("\\.[0-9]*$", "", FCdata$ID)
  FCdata2 = FCdata[!duplicated(FCdata$ID),]
  FC_data3 <- FCdata2 %>% 
    mutate(fold = -log10(FCdata2$Fold)) %>% 
    drop_na()
  # Couldn't find a way to remove infinite values
  
  # Match exon regions with genes identified from data
  # toy_data or filtered data
  sigRegions <- exoRanges[na.omit(match(FC_data3$ID, names(exoRanges)))]
  mcols(sigRegions) <- FC_data3[match(names(sigRegions), FC_data3$ID), ]
  sigRegions
  sigRegions <- keepSeqlevels(sigRegions,
                              value = c(1:5),
                              pruning.mode = "tidy"
  )
  
  # Now plot
  plotGrandLinear(sigRegions, aes(y = fold), cutoff.size = 1) + scale_color_brewer(palette = "Dark2") +
    xlab("Chromosome") +
    ggtitle("Significantly enriched genome positions")
}
