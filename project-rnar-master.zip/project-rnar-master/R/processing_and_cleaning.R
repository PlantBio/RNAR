#function processes data and prints values
processdat <- function(rawdata) {
  print(mutate(cleandat(rawdata), p.values = pvalues(rawdata), p.adjust = padjust(rawdata)))
}
