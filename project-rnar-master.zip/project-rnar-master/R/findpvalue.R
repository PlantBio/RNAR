#function calculates p-value
findpvalue <- function(x,y) {
  t.test(x,y,var.equal = FALSE)$p.value
}
