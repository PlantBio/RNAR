cleandat <- function(samples) {
  samples <- samples %>% drop_na()
  
  trialmean <- samples %>%
    gather(key = "cr", value = "value", -1) %>%
    mutate(crsub = substr(cr, 1, 5)) %>%
    group_by(ID, crsub) %>%
    summarize(mean = mean(value)) %>%
    spread(crsub, mean)
  
  repmean <- trialmean %>%
    gather(key = "cr", value = "value", -1) %>%
    mutate(csub = substr(cr, 1, 2)) %>%
    group_by(ID, csub) %>%
    summarize(mean = mean(value)) %>%
    spread(csub, mean)
  
  samples %>%
    left_join(trialmean, by = "ID") %>%
    left_join(repmean, by = "ID")
}
